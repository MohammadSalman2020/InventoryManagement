﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmPurchase : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //lblTotal.Visible = false;
            if (!IsPostBack)
            {
                lblmsg.Visible = false;
                btnUpdate.Visible = false;
                mthdFillGrid();
                MthdFillDrpVendor();
                MthdFillDrpWarehouse();
                MthdFillRepeater();
                file_Decision.Visible = false;
            }

        }

        //DBInventoryEntities db = new DBInventoryEntities();
        DBInventoryEntities db = new DBInventoryEntities();
        public void mthdFillGrid()
        {
            GridView1.DataSource = (from a in db.tblProducts
                                    select new { a.ProductID, a.ProductName }).ToList();
            GridView1.DataBind();
        }


        public void MthdFillDrpVendor()
        {

            DrpVendor.DataSource = (from a in db.tblVendors select new { a.VendorID, a.FirstName }).ToList();
            DrpVendor.DataValueField = "VendorID";
            DrpVendor.DataTextField = "FirstName";
            DrpVendor.DataBind();



        }
        public void MthdFillDrpWarehouse()
        {

            DrpWarehouse.DataSource = (from a in db.tblWarehouses select new { a.WarehouseID, a.WarehouseName }).ToList();
            DrpWarehouse.DataValueField = "WarehouseID";
            DrpWarehouse.DataTextField = "WarehouseName";
            DrpWarehouse.DataBind();



        }
        public bool Empty()
        {
            if (txtPurchaseDate.Text.Trim() == string.Empty || txtRemarks.Text.Trim() == string.Empty
                || txtShipingCost.Text.Trim() == string.Empty || txtShipment.Text.Trim() == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtPurchaseDate.Text = "";
            txtRemarks.Text = "";
            txtShipingCost.Text = "";
            txtShipment.Text = "";


        }

        protected void txtPricePerUnit_TextChanged(object sender, EventArgs e)
        {
            //float Quantity = float.Parse(txtQuantity.Text);
            //float Price = float.Parse(txtUnit.Text);


            //float Total = Quantity * Price;

            //lblTotal.Visible = true;

            //lblTotal.InnerText = " " + Total.ToString();
        }

        protected void BtnSend_Click(object sender, EventArgs e)
        {
            //MPE.Show();
        }

        public void MthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepPurchase().ToList().OrderByDescending(p => p.PurchaseID);
            Repeater1.DataBind();
        }


        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                MthdAddPurchase();
                MthdFillRepeater();
                Response.Redirect("FrmPurchase.aspx");
                lblmsg.Visible = true;
                lblmsg.Text = "Added successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }



        }
        public void MthdAddPurchase()
        {
          

            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;

                if (unit.Text.Trim() != "" || measurement.Text.Trim() != "" || quantity.Text.Trim() != "")
                {
                    string videofile = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    string path = "/PuchaseOrderPicture/" + videofile;
                    if (FileUpload1.PostedFile != null)
                    {
                        videofile = Path.GetFileName(FileUpload1.PostedFile.FileName);

                        if (videofile != "")
                        {
                            db.spAddNewPurchase(int.Parse(DrpVendor.SelectedValue.ToString()),
                         Convert.ToDateTime(txtPurchaseDate.Text), txtShipment.Text,
                         int.Parse(DrpWarehouse.SelectedValue.ToString()), double.Parse(txtShipingCost.Text),
                         txtRemarks.Text, path, "", int.Parse(prodID.Text),
                         measurement.Text, double.Parse(quantity.Text.ToString()), double.Parse(unit.Text));
                            db.SaveChanges();

                            // fileimagesave.SaveAs("images/"+ imgfile);
                            FileUpload1.SaveAs(Server.MapPath("~/PuchaseOrderPicture/") + videofile);
                           

                        }
                        else
                        {
                            lblmsg.Visible = true;
                            lblmsg.Text = "No Files To upload";
                            lblmsg.ForeColor = System.Drawing.Color.Red;
                        }

                    }




                }
                else
                {
                    continue;
                }


            }
         
            MthdClear();
        }
        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                   
                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblPurchase obj1 = db.tblPurchases.FirstOrDefault(r => r.PurchaseID == id);



                    



                    txtShipment.Text = obj1.ShipmentID;
                    txtShipingCost.Text = obj1.ShippingCost.ToString();
                    txtRemarks.Text = obj1.Remarks;
                    DrpVendor.SelectedValue = obj1.VendorID.ToString();
                    DrpWarehouse.SelectedValue = obj1.WarehouseID.ToString();


                    string test11 = obj1.PurchaseDate.ToString();
                    txtPurchaseDate.Text = DateTime.Parse(test11).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    ////GridView1.DataSource = (from a in db.tblPurchaseDetails
                    ////                      select new { a.ProductID, a.PurchaseID }).ToList().Where(p=>p.PurchaseID==id);
                    ////GridView1.DataBind();



                    //var rec  =  db.tblPurchaseDetails.ToList().Where(p=>p.PurchaseID==id);

                    var obj2 = db.tblPurchaseDetails.Where(r => r.PurchaseID == id).ToList();



                                

                    var x = db.spFillGrtidOnEditPurchaseCratedBySiddiqueMaster(id).FirstOrDefault();

                    GridView1.DataSource = db.spFillGrtidOnEditPurchaseCratedBySiddiqueMaster(id).ToList();
                    GridView1.DataBind();

                 //   for(int i=0;i<x.)
                    

                    for (int i = 0; i < obj2.Count; i++)
                    {

                        Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                        Label ProductName = GridView1.Rows[i].FindControl("lblproductname") as Label;
                        TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                        TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                        TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;


                        int y = int.Parse(obj2[i].ProductID.ToString());
                        var rec = db.tblProducts.Where(a => a.ProductID == y).FirstOrDefault();

                        prodID.Text = obj2[i].ProductID.ToString();
                        unit.Text = obj2[i].PricePerUnit.ToString();
                        measurement.Text = obj2[i].Measurement.ToString();
                        quantity.Text = obj2[i].Quantity.ToString();
                        ProductName.Text = rec.ProductName.ToString();

                    }

                  

                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;


                    DivFile.Visible = false;
                    file_Decision.Visible = true;

                    break;
            }
        }

        protected void rdyes_CheckedChanged(object sender, EventArgs e)
        {
            DivFile.Visible = true;
            btnUpdate.Visible = true;
            btnAdd.Visible = false;
        }

        protected void rdno_CheckedChanged(object sender, EventArgs e)
        {
            DivFile.Visible = false;
            btnUpdate.Visible = true;
            btnAdd.Visible = false;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdUpdatePurchase();
                MthdFillRepeater();
                Response.Redirect("FrmPurchase.aspx");
                lblmsg.Visible = true;
                lblmsg.Text = "Record Updated Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdUpdatePurchase()
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblPurchases.Where(a => a.PurchaseID == id).FirstOrDefault();
                if (row != null)
                {
               


                    if (FileUpload1.HasFile)
                    {
                        string FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                        string Picturepath = "/PuchaseOrderPicture/" + FileName;

                        FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);

                        // fileimagesave.SaveAs("images/"+ imgfile);
                        FileUpload1.SaveAs(Server.MapPath("~/PuchaseOrderPicture/") + FileName);


                        row.PoImage = Picturepath;
                        row.PurchaseDate = Convert.ToDateTime(txtPurchaseDate);
                        row.Remarks = txtRemarks.Text;
                        row.ShipmentID = txtShipment.Text;
                        row.ShippingCost = double.Parse(txtShipingCost.Text);
                        row.VendorID = int.Parse(DrpVendor.SelectedValue.ToString());
                        row.WarehouseID = int.Parse(DrpWarehouse.SelectedValue.ToString());

                        db.SpDeletePurchaseDetail(id);
                        db.SaveChanges();

                       // var obj2 = db.tblPurchaseDetails.Where(r => r.PurchaseID == id).ToList();
                   

                        for (int i = 0; i < GridView1.Rows.Count; i++)
                        {

                            Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                            TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                            TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                            TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;

                            if (unit.Text.Trim() != "" || measurement.Text.Trim() != "" || quantity.Text.Trim() != "")
                            {
                                //obj2[i].PricePerUnit = double.Parse(unit.Text);
                                //obj2[i].Measurement = measurement.Text;
                                //obj2[i].Quantity = double.Parse(quantity.Text);


                                db.SpUpdateCompletePurchase(id, int.Parse(prodID.Text), measurement.Text, double.Parse(quantity.Text.ToString()), double.Parse(unit.Text.ToString()));
                                db.SaveChanges();

                            }
                            else
                            {
                                lblmsg.Visible = true;
                                lblmsg.Text = "Please Enter Details of Products";
                                lblmsg.ForeColor = System.Drawing.Color.Red;
                            }
                        }

                    }
                    else
                    {
                        row.PurchaseDate = Convert.ToDateTime(txtPurchaseDate.Text);
                        row.Remarks = txtRemarks.Text;
                        row.ShipmentID = txtShipment.Text;
                        row.ShippingCost = double.Parse(txtShipingCost.Text);
                        row.VendorID = int.Parse(DrpVendor.SelectedValue.ToString());
                        row.WarehouseID = int.Parse(DrpWarehouse.SelectedValue.ToString());

                        db.SpDeletePurchaseDetail(id);
                        db.SaveChanges();

                     //   var obj2 = db.tblPurchaseDetails.Where(r => r.PurchaseID == id).ToList();
                        for (int i = 0; i < GridView1.Rows.Count; i++)
                        {
                            Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                            TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                            TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                            TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;

                            if (unit.Text.Trim() != "" || measurement.Text.Trim() != "" || quantity.Text.Trim() != "")
                            {
                                //obj2[i].PricePerUnit = double.Parse(unit.Text);
                                //obj2[i].Measurement = measurement.Text;
                                //obj2[i].Quantity = double.Parse(quantity.Text);

                                db.SpUpdateCompletePurchase(id, int.Parse(prodID.Text), measurement.Text, double.Parse(quantity.Text.ToString()), double.Parse(unit.Text.ToString()));
                                db.SaveChanges();

                            }
                            else
                            {
                                continue;
                            }
                        }


                    }
                 

                 


                    db.SaveChanges();



                    btnAdd.Visible = true;
                    btnUpdate.Visible = false;



                    MthdClear();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }

            }
            catch (Exception ex)
            {
               
            }
        }
    }
}