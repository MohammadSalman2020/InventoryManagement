﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmProduct1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if(!IsPostBack)
            {
                mthdFillDrpType();
            }

            lblmsg.Visible = false;
            mthdFillRepeater();
        }

        DBInventoryEntities db = new DBInventoryEntities();



        public void mthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepProductType().ToList().OrderByDescending(p => p.ProductID);
            Repeater1.DataBind();
        }
        public bool Empty()
        {
            if (txtBrand.Text.Trim() == string.Empty || txtProductName.Text.Trim() == string.Empty
                || txtProductNo.Text.Trim() == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtBrand.Text = "";
            txtProductName.Text = "";
            txtProductNo.Text = "";

        }

        public void mthdFillDrpType()
        {
            DrpType.DataSource = (from a in db.tblProductTypes select new { a.TypeID, a.TypeName }).ToList();
            DrpType.DataValueField = "TypeID";
            DrpType.DataTextField = "TypeName";
            DrpType.DataBind();
        
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmVendor.aspx");
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdAddProduct();
                mthdFillRepeater();

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdAddProduct()
        {
            tblProduct obj = new tblProduct();



            obj.Brand = txtBrand.Text;
            obj.ProductName = txtProductName.Text;
            obj.ProductNo = txtProductNo.Text;
            obj.TypeID = int.Parse(DrpType.SelectedValue.ToString());

            db.tblProducts.Add(obj);
            db.SaveChanges();

            lblmsg.Visible = true;
            lblmsg.Text = "Registered successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdClear();
              
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblProduct obj1 = db.tblProducts.FirstOrDefault(r => r.ProductID == id);


                    txtProductNo.Text = obj1.ProductNo;
                    txtProductName.Text = obj1.ProductName;
                    txtBrand.Text = obj1.Brand;
                    DrpType.SelectedValue = obj1.TypeID.ToString();


                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdUpdateProduct();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdUpdateProduct()
        {
            int id = int.Parse(HiddenField1.Value);
            var row = db.tblProducts.Where(a => a.ProductID == id).FirstOrDefault();
            if (row != null)
            {


                row.ProductName = txtProductName.Text;
                row.ProductNo = txtProductNo.Text;

                row.Brand = txtBrand.Text;
                row.TypeID = int.Parse(DrpType.SelectedValue.ToString());

                db.SaveChanges();
                lblmsg.Visible = true;
                lblmsg.Text = "Record updated successfully!";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                btnUpdate.Visible = false;
                btnAdd.Visible = true;

                MthdClear();

            }
            else
            {
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
            }
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            Response.Redirect("FrmProduct.aspx");
        }

    }
}