﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmStock : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if(!IsPostBack)
            {
                MthdFillDrpPlace();
            }
        }
      
        protected void btnFilter_Click(object sender, EventArgs e)
        {

            int x = DrpFilter.SelectedIndex;

            if(x==0)
            {
                string PlaceName = DrpPlace.SelectedItem.Text;

                Repeater1.DataSource = db.SpFillRepStockForProduct(PlaceName).ToList().OrderByDescending(p => p.StockID);
                Repeater1.DataBind();
            }
            else if(x==1)
            {
                string Placetype = DrpFilter.SelectedItem.Text;
                string PlaceName = DrpPlace.SelectedItem.Text;

                Repeater1.DataSource = db.SpFillRepStockForWarehouse(PlaceName, Placetype).ToList().OrderByDescending(p => p.StockID);
                Repeater1.DataBind();
            }
            else if(x==2)
            {
                string Placetype = DrpFilter.SelectedItem.Text;
                string PlaceName = DrpPlace.SelectedItem.Text;

                Repeater2.DataSource = db.SpFillRepStockForVehicle1(PlaceName,Placetype).ToList().OrderByDescending(p => p.StockID);
                Repeater2.DataBind();
            }
        
        }
        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillDrpPlace()
        {
            int x = DrpFilter.SelectedIndex;


            if(x==0)
            {
                // int ID = int.Parse(DrpProject.SelectedValue.ToString());


            //var rec = (from a in db.tblPacketProjects
            //           join t2 in db.tblPackets on a.PacketID equals t2.PacketID
            //           select new { a.PacketID, a.ProjectID, t2.Packet }).Where(p => p.ProjectID == ID).ToList();

                DrpPlace.DataSource = (from an in db.tblCurrentStocks
                                       join t2 in db.tblProducts on an.ProductID equals t2.ProductID
                                       select new { an.ProductID, t2.ProductName }).ToList();
                DrpPlace.DataValueField = "ProductID";
                DrpPlace.DataTextField = "ProductName";
                DrpPlace.DataBind();
            }

            else if(x==1)
            {
                DrpPlace.DataSource = (from an in db.tblCurrentStocks
                                       join t2 in db.tblWarehouses on an.PlaceID equals t2.WarehouseID
                                       select new { an.PlaceID, t2.WarehouseName ,an.PlaceType}).Where(p=>p.PlaceType=="Warehouse").ToList();
                DrpPlace.DataValueField = "PlaceID";
                DrpPlace.DataTextField = "WarehouseName";
                DrpPlace.DataBind();
            }

            else if(x==2)
            {
                DrpPlace.DataSource = (from an in db.tblCurrentStocks
                                       join t2 in db.tblVehicles on an.PlaceID equals t2.VehicleID
                                       select new { an.PlaceID, t2.VehicleNo, an.PlaceType }).Where(p => p.PlaceType == "Truck").ToList();
                DrpPlace.DataValueField = "PlaceID";
                DrpPlace.DataTextField = "VehicleNo";
                DrpPlace.DataBind();
            }



        }

        protected void DrpFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpPlace();
        }
    }
}