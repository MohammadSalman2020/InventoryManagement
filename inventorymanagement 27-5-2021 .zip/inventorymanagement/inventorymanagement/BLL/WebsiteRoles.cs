﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace inventorymanagement.BLL
{
    public class WebsiteRoles
    {
        public static string Admin = "1";
        public static string WareHouseManager = "2";
        public static string WareHouseWorker = "3";
        public static string SolarInstaller = "4";
        public static string ElectricalInstaller = "5";
        public static string ConstructionInstaller = "6";
        public static string Inspector = "7";


        public static bool IsAdministrater()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.Admin)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsWareHouseManager()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.WareHouseManager)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsWareHouseWorker()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.WareHouseWorker)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsSolarInstaller()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.SolarInstaller)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsElectricalInstaller()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.ElectricalInstaller)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsConstructionInstaller()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.ConstructionInstaller)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsInspector()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == WebsiteRoles.Inspector)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}