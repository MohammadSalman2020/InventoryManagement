﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmUserManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                mthdFillDrpRole();
            }
            btnUpdate.Visible = false;
            lblmsg.Visible = false;
            mthdFillRepeater();
        }

        //DBInventoryEntities db = new DBInventoryEntities();

        DBInventoryEntities db = new DBInventoryEntities();

        public void mthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepUserManagement1().ToList().OrderByDescending(p => p.LoginID);
            Repeater1.DataBind();
        }
        public void mthdFillDrpRole()
        {
            DrpRole.DataSource = (from c in db.tblRoles select new { c.RoleID, c.RoleDesc }).ToList();
            DrpRole.DataTextField = "RoleDesc";
            DrpRole.DataValueField = "RoleID";
            DrpRole.DataBind();
        }
        public bool Empty()
        {
            if (DrpRole.Text.Trim() == string.Empty || txtBatchNo.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty
                || txtFirstName.Text.Trim() == string.Empty || txtLastName.Text.Trim() == string.Empty || txtPhone.Text.Trim() == string.Empty)
            {
                //lblmsg.Visible = true;
                //lblmsg.Text = "Fill all feilds";
                //lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                MthdADDUser();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdClear()
        {
            txtBatchNo.Text = "";
            txtEmail.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtPhone.Text = "";
            txtPWD.Text = "";
        }

        public void MthdADDUser()
        {

            tblLogin obj = new tblLogin();

            string videofile = Path.GetFileName(FileUpload1.PostedFile.FileName);
            string path = "/UserImages/" + videofile;
            if (FileUpload1.PostedFile != null)
            {
                videofile = Path.GetFileName(FileUpload1.PostedFile.FileName);

                if (videofile != "")
                {

                    obj.FirstName = txtFirstName.Text;
                    obj.LastName = txtLastName.Text;
                    obj.EmailID = txtEmail.Text;
                    obj.Pwd = txtPWD.Text;
                    obj.BadgeNo = txtBatchNo.Text;
                    obj.PhotoName = videofile;
                    obj.PhoneLocation = path;
                    obj.PhoneNumber = txtPhone.Text;
                    obj.RoleID = int.Parse(DrpRole.SelectedValue.ToString());


                    db.tblLogins.Add(obj);
                    db.SaveChanges();

                    // fileimagesave.SaveAs("images/"+ imgfile);
                    FileUpload1.SaveAs(Server.MapPath("~/UserImages/") + videofile);
                    lblmsg.Visible = true;
                    lblmsg.Text = "Registered successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                    MthdClear();
                }


            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
               
                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblLogin obj1 = db.tblLogins.FirstOrDefault(r => r.LoginID == id);


                    txtFirstName.Text = obj1.FirstName;
                    txtLastName.Text = obj1.LastName;
                    txtBatchNo.Text = obj1.BadgeNo;
                    txtEmail.Text = obj1.EmailID;
                    txtPhone.Text = obj1.PhoneNumber;
                    DrpRole.SelectedValue = obj1.RoleID.ToString();
                    txtPWD.Text = obj1.Pwd;


                    divFileUpload.Visible = false;
                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdUpdateUser();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdUpdateUser()
        {
            int id = int.Parse(HiddenField1.Value);
            var row = db.tblLogins.Where(a => a.LoginID == id).FirstOrDefault();
            if (row != null)
            {
                if (!Empty())
                {

                    row.FirstName = txtFirstName.Text;
                    row.LastName = txtLastName.Text;
                    row.PhoneNumber = txtPhone.Text;
                    row.Pwd = txtPWD.Text;
                    row.BadgeNo = txtBatchNo.Text;
                    row.EmailID = txtEmail.Text;
                    row.RoleID = int.Parse(DrpRole.SelectedValue.ToString());



                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record updated successfully!";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                    btnUpdate.Visible = false;
                    btnAdd.Visible = true;
                  
                    MthdClear();
                    divFileUpload.Visible = true;
                }
                else
                {
                    btnUpdate.Visible = true;
                    btnAdd.Visible = false;
                }

            }
        }
    }
}