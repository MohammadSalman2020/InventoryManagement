﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DBInventoryEntities db = new DBInventoryEntities();

            var totalProductsPurchased = db.tblPurchaseDetails.Count(a => a.ProductID > 0).ToString();
            lblTotalProductPurchased.InnerText = totalProductsPurchased;


            var TotalCustomer = db.tblCustomers.Count(a => a.CustomerID > 0).ToString();
            lblCustomers.InnerText = TotalCustomer;

            var TotalVendors = db.tblVendors.Count(a => a.VendorID > 0).ToString();
            lblVendors.InnerText = TotalVendors;

            var TotalTrucks = db.tblVehicles.Count(a => a.VehicleID > 0).ToString();
            lblTrucks.InnerText = TotalTrucks;




        }
    }
}