﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using inventorymanagement.BLL;


namespace inventorymanagement
{
    public partial class Frmlogin : System.Web.UI.Page
    {

        //DBInventoryEntities db = new DBInventoryEntities();
        DBInventoryEntities db = new DBInventoryEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
        }

        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                var rec = db.tblLogins.Where(b => b.EmailID == TxtUserName.Text && b.Pwd.Equals(TxtPassword.Text)).FirstOrDefault();


                if (rec != null)
                {
                    Session["Email"] = TxtUserName.Text;
                    Session["RoleID"] = rec.RoleID;

                    if (WebsiteRoles.IsAdministrater())
                    {
                        Response.Redirect("Dashboard.aspx");
                    }
                    else if (WebsiteRoles.IsConstructionInstaller())
                    {
                        Response.Redirect("FrmSchedule.aspx");
                    }
                    else if (WebsiteRoles.IsElectricalInstaller())
                    {
                        Response.Redirect("FrmSchedule.aspx");
                    }
                    else if (WebsiteRoles.IsInspector())
                    {
                        Response.Redirect("FrmSchedule.aspx");
                    }
                    else if (WebsiteRoles.IsSolarInstaller())
                    {
                        Response.Redirect("FrmSchedule.aspx");
                    }
                    else if (WebsiteRoles.IsWareHouseManager())
                    {
                        Response.Redirect("FrmStock.aspx");
                    }
                    else if (WebsiteRoles.IsWareHouseWorker())
                    {
                        Response.Redirect("FrmSchedule.aspx");
                    }
                }
                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Incorrect Password";
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                lblmsg.Text = ex.Message;
            }
        }
    }
}