﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmProductType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
          
            mthdFillRepeater();

        }
        //DBInventoryEntities db = new DBInventoryEntities();

        DBInventoryEntities db = new DBInventoryEntities();

        public void mthdFillRepeater()
        {
            Repeater1.DataSource = db.tblProductTypes.ToList().OrderByDescending(p => p.TypeID);
            Repeater1.DataBind();
        }
        public bool Empty()
        {
            if (txtDesc.Text.Trim() == string.Empty || txtType.Text.Trim() == string.Empty )
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtType.Text = "";
            txtDesc.Text = "";
    
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdAddProductType();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdAddProductType()
        {
            tblProductType obj = new tblProductType();



            obj.TypeDesc = txtDesc.Text;
            obj.TypeName = txtType.Text;
       


            db.tblProductTypes.Add(obj);
            db.SaveChanges();

            lblmsg.Visible = true;
            lblmsg.Text = "Registered successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdClear();
              
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblProductType obj1 = db.tblProductTypes.FirstOrDefault(r => r.TypeID == id);


                    txtType.Text = obj1.TypeName;
                    txtDesc.Text = obj1.TypeDesc;
              



                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdUpdateProductType();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdUpdateProductType()
        {
            int id = int.Parse(HiddenField1.Value);
            var row = db.tblProductTypes.Where(a => a.TypeID == id).FirstOrDefault();
            if (row != null)
            {
              

                    row.TypeDesc = txtDesc.Text;
                    row.TypeName = txtType.Text;
              



                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record updated successfully!";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                    btnUpdate.Visible = false;
                    btnAdd.Visible = true;

                    MthdClear();

                }
                else
                {
                    btnUpdate.Visible = true;
                    btnAdd.Visible = false;
                }

            }
        }
    }
