﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmProject : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MthdFillChkSolar();
                MthdFillChkElectrical();
                MthdFillChkConstruction();
                MthdFillDrpCustomer();
                btnUpdate.Visible = false;
                lblmsg.Visible = false;
                MthdFillRepeater();
                MthdFillDrpProject();
                MthdFillDrpPacket();
                mthdFillGrid();
            }
        }
        //DBInventoryEntities db = new DBInventoryEntities();

        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillChkSolar()
        {
            ChkSolarInstaller.DataSource = (from a in db.tblLogins
                                            let x = a.FirstName + " " + a.LastName
                                            select new { a.LoginID, a.RoleID, x }).Where(p => p.RoleID == 4).ToList().OrderByDescending(p=>p.LoginID);
            ChkSolarInstaller.DataValueField = "LoginID";
            ChkSolarInstaller.DataTextField = "x";
            ChkSolarInstaller.DataBind();
        }
        public void mthdFillGrid()
        {
            //var rec = (from a in db.tblPacketProjects
            //           join t2 in db.tblPackets on a.PacketID equals t2.PacketID
            //           select new { a.PacketID, a.ProjectID, t2.Packet }).Where(p => p.ProjectID == ID).ToList();

            int ID = int.Parse(DrpPackets.SelectedValue.ToString());
            GridView1.DataSource = db.SpFillGridAtProject(ID).ToList();
            GridView1.DataBind();
        }

        public void MthdFillChkElectrical()
        {
            chkElectric.DataSource = (from a in db.tblLogins
                                      let x = a.FirstName + " " + a.LastName
                                      select new { a.LoginID, a.RoleID, x }).Where(p => p.RoleID == 5)
                .ToList().OrderByDescending(p => p.LoginID);
            chkElectric.DataValueField = "LoginID";
            chkElectric.DataTextField = "x";
            chkElectric.DataBind();
        }
        public void MthdFillChkConstruction()
        {
            ChkConstruction.DataSource = (from a in db.tblLogins
                                          let x = a.FirstName + " " + a.LastName
                                          select new { a.LoginID, x, a.RoleID }).Where(p => p.RoleID == 6).ToList().OrderByDescending(p => p.LoginID);
            ChkConstruction.DataValueField = "LoginID";
            ChkConstruction.DataTextField = "x";
            ChkConstruction.DataBind();
        }

        public void MthdFillDrpCustomer()
        {
            DrpCustomer.DataSource = (from a in db.tblCustomers
                                      let x = a.FirstName + " " + a.LastName
                                      select new { a.CustomerID, x }).ToList();
            DrpCustomer.DataValueField = "CustomerID";
            DrpCustomer.DataTextField = "x";
            DrpCustomer.DataBind();
        }
        public void MthdFillDrpProject()
        {
            DrpProject.DataSource = (from a in db.tblProjects
                                     select new { a.Project, a.ProjectID }).ToList();

            DrpProject.DataValueField = "ProjectID";
            DrpProject.DataTextField = "Project";
            DrpProject.DataBind();
        }
        public void MthdFillDrpPacket()
        {

           // int ID = int.Parse(DrpProject.SelectedValue.ToString());


            //var rec = (from a in db.tblPacketProjects
            //           join t2 in db.tblPackets on a.PacketID equals t2.PacketID
            //           select new { a.PacketID, a.ProjectID, t2.Packet }).Where(p => p.ProjectID == ID).ToList();


            DrpPackets.DataSource = (from a in db.tblPackets
                                    select new { a.PacketID, a.Packet }).ToList().OrderByDescending(p=>p.PacketID);
            DrpPackets.DataValueField = "PacketID";
            DrpPackets.DataTextField = "Packet";
            DrpPackets.DataBind();
        }
        public bool Empty()
        {
            if (txtConstructionDate.Text.Trim() == string.Empty || txtElectricDate.Text.Trim() == string.Empty
                || txtEndDate.Text.Trim() == string.Empty || txtProjectName.Text.Trim() == string.Empty
                || txtSolarDate.Text.Trim() == string.Empty || txtStartDate.Text.Trim() == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtStartDate.Text = "";
            txtSolarDate.Text = "";
            txtProjectName.Text = "";
            txtEndDate.Text = "";
            txtElectricDate.Text = "";
            txtConstructionDate.Text = "";
        }

        public void MthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepProject().ToList().OrderByDescending(p => p.ProjectID);
            Repeater1.DataBind();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            
            if (!Empty())
            {
                MthdAddProject();
                MthdFillRepeater();
                MthdClear();
                chkElectric.ClearSelection();
                ChkSolarInstaller.ClearSelection();
                ChkConstruction.ClearSelection();
                lblmsg.Visible = true;
                lblmsg.Text = "Project Added Succesfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdAddProject()
        {
            tblProject obj = new tblProject();

            obj.Project = txtProjectName.Text;
            obj.CustomerID = int.Parse(DrpCustomer.SelectedValue.ToString());
            obj.ProjectStartDate = Convert.ToDateTime(txtSolarDate.Text);
            obj.ProjectEndDate = Convert.ToDateTime(txtEndDate.Text);

            db.tblProjects.Add(obj);
            db.SaveChanges();

            tblProjectAssignee obj2 = new tblProjectAssignee();
            var rec = db.tblProjects.Max(p => p.ProjectID);

            foreach (ListItem item in ChkSolarInstaller.Items)
            {

                if (item.Selected)
                {
                    obj2.ProjectID = rec;

                    obj2.TaskDate = Convert.ToDateTime(txtSolarDate.Text);

                    obj2.UserID = int.Parse(item.Value);


                    obj2.UserType = "Solar Installer";



                    db.tblProjectAssignees.Add(obj2);
                    db.SaveChanges();



                }
            }
            foreach (ListItem item in chkElectric.Items)
            {

                if (item.Selected)
                {
                    obj2.ProjectID = rec;

                    obj2.TaskDate = Convert.ToDateTime(txtElectricDate.Text);

                    obj2.UserID = int.Parse(item.Value);


                    obj2.UserType = "Electric Installer";



                    db.tblProjectAssignees.Add(obj2);
                    db.SaveChanges();



                }
            }
            foreach (ListItem item in ChkConstruction.Items)
            {

                if (item.Selected)
                {
                    obj2.ProjectID = rec;

                    obj2.TaskDate = Convert.ToDateTime(txtConstructionDate.Text);

                    obj2.UserID = int.Parse(item.Value);


                    obj2.UserType = "Construction Installer";



                    db.tblProjectAssignees.Add(obj2);
                    db.SaveChanges();



                }
            }


            for (int i = 0; i < GridView1.Rows.Count; i++)
            {

                TextBox quantity = GridView1.Rows[i].FindControl("txtReqQty") as TextBox;

                if (quantity.Text.Trim() != "")
                {
                    tblPacketProject obj1 = new tblPacketProject();
                    obj1.PacketID = int.Parse(DrpPackets.SelectedValue.ToString());
                    obj1.ProjectID = int.Parse(DrpProject.SelectedValue.ToString());
                    obj1.QtyRequired = float.Parse(quantity.Text);

                    db.tblPacketProjects.Add(obj1);
                    db.SaveChanges();





                }
                else
                {
                    continue;
                }


            }






        }
     

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblProject obj1 = db.tblProjects.FirstOrDefault(r => r.ProjectID == id);


                    string date = obj1.ProjectStartDate.ToString();

                    txtStartDate.Text = DateTime.Parse(date).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    string date1 = obj1.ProjectEndDate.ToString();

                    txtEndDate.Text = DateTime.Parse(date1).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    txtProjectName.Text = obj1.Project;
                    DrpCustomer.SelectedValue = obj1.CustomerID.ToString();





                    var solars = db.tblProjectAssignees.Where(p => p.ProjectID == id && p.UserType == "Solar Installer").ToList();
                    var elect = db.tblProjectAssignees.Where(p => p.ProjectID == id && p.UserType == "Electric Installer").ToList();
                    var construction = db.tblProjectAssignees.Where(p => p.ProjectID == id && p.UserType == "Construction Installer").ToList();


                    if (solars != null)
                    {
                        txtSolarDate.Text = DateTime.Parse(solars[0].TaskDate.ToString()).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    }
                    if (elect != null)
                    {
                        txtElectricDate.Text = DateTime.Parse(elect[0].TaskDate.ToString()).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    }

                    if (construction != null)
                    {
                        txtConstructionDate.Text = DateTime.Parse(construction[0].TaskDate.ToString()).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    }

                    int TotalSolarAssignee = solars.Count;
                    int SolarAssigneeCount = 0;

                    for (int i = 0; i < ChkSolarInstaller.Items.Count; i++)
                    {

                            if (i < TotalSolarAssignee)
                            {
                                SolarAssigneeCount = SolarAssigneeCount + 1;
                            }
                           if (ChkSolarInstaller.Items[i].Value == solars[SolarAssigneeCount - 1].UserID.ToString())
                           {
                               ChkSolarInstaller.Items[i].Selected = true;
                           }
                   

                    }

                      int TotalElectricalAssignee = elect.Count;
                      int ElectricalAssigneeCount = 0;

                    for (int i = 0; i < chkElectric.Items.Count; i++)
                    {
                        if (i < TotalElectricalAssignee)
                        {
                            ElectricalAssigneeCount = ElectricalAssigneeCount + 1;
                        }
                        if (chkElectric.Items[i].Value == elect[ElectricalAssigneeCount-1].UserID.ToString())
                        {
                            chkElectric.Items[i].Selected = true;
                        }
                     
                    }

                       int TotalContsructionAssignee = construction.Count;
                       int ContsructionAssigneeCount = 0;


                    for (int i = 0; i < ChkConstruction.Items.Count; i++)
                    {
                        if (i < TotalContsructionAssignee)
                        {
                            ContsructionAssigneeCount = ContsructionAssigneeCount + 1;
                        }
                        if (ChkConstruction.Items[i].Value == construction[ContsructionAssigneeCount - 1].UserID.ToString())
                        {
                            ChkConstruction.Items[i].Selected = true;
                        }
                     

                    }





                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;

                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                UpdateProject();
                MthdFillRepeater();
                MthdClear();
                chkElectric.ClearSelection();
                ChkSolarInstaller.ClearSelection();
                ChkConstruction.ClearSelection();
                lblmsg.Visible = true;
                lblmsg.Text = "Project Updated Succesfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void UpdateProject()
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblProjects.Where(a => a.ProjectID == id).FirstOrDefault();
             


                if (row != null)
                {





                    row.ProjectEndDate = Convert.ToDateTime(txtEndDate.Text);

                    row.ProjectStartDate = Convert.ToDateTime(txtStartDate.Text);

                    row.Project = txtProjectName.Text;
                    row.CustomerID = int.Parse(DrpCustomer.SelectedValue.ToString());


                    db.SaveChanges();


                    db.SpDeleteProjectAssignee(id);
                    db.SaveChanges();
                    tblProjectAssignee obj2 = new tblProjectAssignee();


                    foreach (ListItem item in ChkSolarInstaller.Items)
                    {

                        if (item.Selected)
                        {
                            obj2.ProjectID = id;

                            obj2.TaskDate = Convert.ToDateTime(txtSolarDate.Text);

                            obj2.UserID = int.Parse(item.Value);


                            obj2.UserType = "Solar Installer";



                            db.tblProjectAssignees.Add(obj2);
                            db.SaveChanges();



                        }
                    }
                    foreach (ListItem item in chkElectric.Items)
                    {

                        if (item.Selected)
                        {
                            obj2.ProjectID = id;

                            obj2.TaskDate = Convert.ToDateTime(txtElectricDate.Text);

                            obj2.UserID = int.Parse(item.Value);


                            obj2.UserType = "Electric Installer";



                            db.tblProjectAssignees.Add(obj2);
                            db.SaveChanges();



                        }
                    }
                    foreach (ListItem item in ChkConstruction.Items)
                    {

                        if (item.Selected)
                        {
                            obj2.ProjectID = id;

                            obj2.TaskDate = Convert.ToDateTime(txtConstructionDate.Text);

                            obj2.UserID = int.Parse(item.Value);


                            obj2.UserType = "Construction Installer";



                            db.tblProjectAssignees.Add(obj2);
                            db.SaveChanges();



                        }
                    }







                    btnAdd.Visible = true;
                    btnUpdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        protected void DrpProject_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void DrpPackets_SelectedIndexChanged(object sender, EventArgs e)
        {
            mthdFillGrid();
        }
    }
}