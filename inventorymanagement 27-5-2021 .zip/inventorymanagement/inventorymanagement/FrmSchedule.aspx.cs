﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmSchedule : System.Web.UI.Page
    {
        Hashtable HolidayList;  
        protected void Page_Load(object sender, EventArgs e)
        {
          

            CustomizeCalender();



        }
        public void CustomizeCalender()
        {
            HolidayList = Getholiday();
            //Calendar1.Caption = "Schedule";
            Calendar1.FirstDayOfWeek = FirstDayOfWeek.Sunday;
            Calendar1.NextPrevFormat = NextPrevFormat.ShortMonth;
            Calendar1.TitleFormat = TitleFormat.Month;
            Calendar1.ShowGridLines = true;
            Calendar1.DayStyle.Height = new Unit(50);
            Calendar1.DayStyle.Width = new Unit(150);
            Calendar1.DayStyle.HorizontalAlign = HorizontalAlign.Center;
            Calendar1.DayStyle.VerticalAlign = VerticalAlign.Middle;
            Calendar1.OtherMonthDayStyle.BackColor = System.Drawing.Color.AliceBlue;  
        }

        DBInventoryEntities db = new DBInventoryEntities();

        List<Schedule> objtest = new List<Schedule>();

        public void FillClassData()
        {
            string UserTypee = DrpFilter.SelectedItem.Text;


            var rec = (from a in db.SpGetSchedule(UserTypee)
                       select new { a.UserType, a.Fullname, a.TaskDate,a.CustomerAddress }).ToList();

            for (int i = 0; i < rec.Count; i++)
            {
                DateTime dt = DateTime.Parse(rec[i].TaskDate.ToString());
                objtest.Add(new Schedule(dt.ToShortDateString().ToString(), rec[i].CustomerAddress,rec[i].Fullname));
            }

        }

        private Hashtable Getholiday()
        {

            FillClassData();




            Hashtable holiday = new Hashtable();


            for (int i = 0; i < objtest.Count; i++)
            {
                if (holiday[objtest[i].Date.ToString()] != null)
                {
                    string x = holiday[objtest[i].Date.ToString()].ToString();
                    holiday[objtest[i].Date.ToString()] = x + "<br/>" + objtest[i].Name.ToString() + "<br/>" + objtest[i].CustAdd.ToString();
                }
                else
                {
                    holiday[objtest[i].Date.ToString()] = objtest[i].Name.ToString() + "<br/>" + objtest[i].CustAdd.ToString();
                }

            }



            //holiday["12/28/2021"] = "Muharram";
            return holiday;
        }

     

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            if (HolidayList[e.Day.Date.ToShortDateString()] != null)
            {
                Literal literal1 = new Literal();
                literal1.Text = "<br/>";
                e.Cell.Controls.Add(literal1);
                Label label1 = new Label();
                label1.Text = (string)HolidayList[e.Day.Date.ToShortDateString()];
                e.Cell.BackColor = System.Drawing.Color.LawnGreen;
                e.Cell.ForeColor = System.Drawing.Color.Black;
                label1.Font.Size = new FontUnit(FontSize.Small);
                e.Cell.Controls.Add(label1);





            }  
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            LabelAction.Text = "Date changed to :" + Calendar1.SelectedDate.ToShortDateString();
            LabelAction.ForeColor = System.Drawing.Color.Green;
        }

        protected void Calendar1_VisibleMonthChanged(object sender, MonthChangedEventArgs e)
        {
            LabelAction.Text = "Month changed to :" + e.NewDate.ToShortDateString();
            LabelAction.ForeColor = System.Drawing.Color.Green;
        }

        protected void DrpFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillClassData();
        }

       
    }
}