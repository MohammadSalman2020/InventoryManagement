﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace inventorymanagement
{
    public class Schedule
    {
        public string Date;
        public string CustAdd;
        public string Name;

        public Schedule(string date, string CustomerAddress,string name)
        {
            this.Date = date;
            this.CustAdd = CustomerAddress;
            this.Name = name;

        } 
    }
}