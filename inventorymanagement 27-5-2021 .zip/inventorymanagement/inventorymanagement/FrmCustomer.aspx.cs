﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            btnUpdate.Visible = false;
            lblmsg.Visible = false;
            mthdFillRepeater();
        }
        public bool Empty()
        {
            if (txtAddress.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty
              || txtFirstname.Text == string.Empty || txtLastname.Text == string.Empty || txtNumber.Text == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtNumber.Text = "";
            txtLastname.Text = "";
            txtFirstname.Text = "";
            txtEmail.Text = "";
            txtAddress.Text = "";

        }
        //DBInventoryEntities db = new DBInventoryEntities();
        DBInventoryEntities db = new DBInventoryEntities();
        public void mthdFillRepeater()
        {
            Repeater1.DataSource = db.tblCustomers.ToList().OrderByDescending(p => p.CustomerID);
            Repeater1.DataBind();

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                AddCustomer();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void AddCustomer()
        {
            tblCustomer obj = new tblCustomer();



            obj.FirstName = txtFirstname.Text;
            obj.LastName = txtLastname.Text;
            obj.Email = txtEmail.Text;
            obj.CustomerAddress = txtAddress.Text;
            obj.PhoneNumber = txtNumber.Text;
          


            db.tblCustomers.Add(obj);
            db.SaveChanges();

            lblmsg.Visible = true;
            lblmsg.Text = "Registered successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdClear();
              


            
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblCustomer obj1 = db.tblCustomers.FirstOrDefault(r => r.CustomerID == id);


                    txtFirstname.Text = obj1.FirstName;
                    txtLastname.Text = obj1.LastName;
                    txtNumber.Text = obj1.PhoneNumber;
                    txtEmail.Text = obj1.Email;
                    txtAddress.Text = obj1.CustomerAddress;
                 



                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdUpdateCustomer();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdUpdateCustomer()
        {
             int id = int.Parse(HiddenField1.Value);
            var row = db.tblCustomers.Where(a => a.CustomerID == id).FirstOrDefault();
            if (row != null)
            {
                if (!Empty())
                {

                    row.FirstName = txtFirstname.Text;
                    row.LastName = txtLastname.Text;
                    row.Email = txtEmail.Text;
                    row.CustomerAddress = txtAddress.Text;
                    row.PhoneNumber = txtNumber.Text;
                

                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record updated successfully!";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                    btnUpdate.Visible = false;
                    btnAdd.Visible = true;

                    MthdClear();

                }
                else
                {
                    btnUpdate.Visible = true;
                    btnAdd.Visible = false;
                }
            }
        }

    }
}