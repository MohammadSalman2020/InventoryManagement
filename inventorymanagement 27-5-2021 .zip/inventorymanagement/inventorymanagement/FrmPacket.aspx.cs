﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmPacket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            btnUpdate.Visible = false;
            MthdFillRepeater();
            if (!IsPostBack)
            {
                MthdFillDrpProductType();
                MthdFillChkProduct();

            }
        }
        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillDrpProductType()
        {
            DrpProductType.DataSource = (from a in db.tblProductTypes
                                         select new { a.TypeID, a.TypeName }).ToList();

            DrpProductType.DataValueField = "TypeID";
            DrpProductType.DataTextField = "TypeName";
            DrpProductType.DataBind();
        }
        public void MthdFillChkProduct()
        {
            int ID = int.Parse(DrpProductType.SelectedValue.ToString());
            ChkProducts.DataSource = (from a in db.tblProducts
                                      select new { a.TypeID, a.ProductName, a.ProductID }).Where(p => p.TypeID == ID).ToList();

            ChkProducts.DataValueField = "ProductID";
            ChkProducts.DataTextField = "ProductName";
            ChkProducts.DataBind();
        }

        protected void DrpCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillChkProduct();

        }

        public void MthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepPacket().ToList().OrderByDescending(p => p.PacketDetailID);
            Repeater1.DataBind();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtPackName.Text.Trim() != string.Empty)
            {


                AddPacket();
                MthdFillRepeater();

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void AddPacket()
        {
            tblPacket obj = new tblPacket();
            obj.Packet = txtPackName.Text;

            db.tblPackets.Add(obj);
            db.SaveChanges();

            var rec = db.tblPackets.Select(a => a.PacketID).Max();

            tblPacketDetail obj2 = new tblPacketDetail();

            foreach (ListItem item in ChkProducts.Items)
            {
                obj2.ProductID = int.Parse(item.Value);
                obj2.PacketID = rec;

                db.tblPacketDetails.Add(obj2);
                db.SaveChanges();

            }
            ChkProducts.ClearSelection();
            lblmsg.Visible = true;
            lblmsg.Text = "Packet Added Successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;


        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblPacketDetail obj1 = db.tblPacketDetails.FirstOrDefault(r => r.PacketDetailID == id);

                    int x =  int.Parse(obj1.PacketID.ToString());

                  //  HiddenField2.Value = x.ToString();

                    DivProduct.Visible = false;

                   

                    ChkProducts.DataSource = (from a in db.SpFillChkProduct()
                                              select new { a.PacketDetailID, a.ProductName,a.ProductID }).Where(p => p.PacketDetailID == id).ToList();

                    ChkProducts.DataValueField = "ProductID";
                    ChkProducts.DataTextField = "ProductName";
                    ChkProducts.DataBind();

                    tblPacket obj = db.tblPackets.FirstOrDefault(r => r.PacketID == x);

                    ChkProducts.SelectedValue = obj1.ProductID.ToString();

                    txtPackName.Text = obj.Packet;


                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(txtPackName.Text.Trim()!=string.Empty)
            {
                UpdatePacket();
                MthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void UpdatePacket()
        {
            int id = int.Parse(HiddenField1.Value);
            var row = db.tblPacketDetails.Where(a => a.PacketDetailID == id).FirstOrDefault();

            int x = int.Parse(row.PacketID.ToString());

            if (row != null)
            {


                row.ProductID = int.Parse(ChkProducts.SelectedValue.ToString());

                var obj = db.tblPackets.FirstOrDefault(r => r.PacketID == x);

                obj.Packet = txtPackName.Text;


                db.SaveChanges();
                lblmsg.Visible = true;
                lblmsg.Text = "Record updated successfully!";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                btnUpdate.Visible = false;
                btnAdd.Visible = true;
                DivProduct.Visible = true;
                ChkProducts.ClearSelection();
                MthdFillChkProduct();
                txtPackName.Text = "";

            }
            else
            {
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
            }
        }
    }
}