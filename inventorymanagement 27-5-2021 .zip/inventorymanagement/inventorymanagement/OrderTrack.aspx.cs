﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class OrderTrack : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //DivCompleted.Visible = false;
            MthdFillRepeater();
        }

        //DBInventoryEntities db = new DBInventoryEntities();

        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillRepeater()
        {
            string Status = DrpSearch.SelectedItem.Text;

            Repeater1.DataSource = db.SpFillRepTrackOrderUpdate(Status).ToList().OrderByDescending(p => p.PurchaseID);
            Repeater1.DataBind();
        }
     

        protected void DrpSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillRepeater();
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblPurchase obj1 = db.tblPurchases.FirstOrDefault(r => r.PurchaseID == id);


                    Session["PurchaseID"] = HiddenField1.Value;


                    Response.Redirect("CompletePurchase.aspx");

                    //txtCurrentMilage.Text = obj1.PurchaseStatus.ToString();
                    //txtMilesDriven.Text = obj1.MilesDriven.ToString();
                    //txtRemarks.Text = obj1.Remarks;

                    //string test11 = obj1.TripDate.ToString();
                    //txtDate.Text = DateTime.Parse(test11).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    //DrpProject.SelectedValue = obj1.ProjectID.ToString();
                    //DrpSupportingVehicle.SelectedValue = obj1.VehicleIDD.ToString();
                    //DrpVehicle.SelectedValue = obj1.VehicleID.ToString();






                    break;
            }
        }
    }
}