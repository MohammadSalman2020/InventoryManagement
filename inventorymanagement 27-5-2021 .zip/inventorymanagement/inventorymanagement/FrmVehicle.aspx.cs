﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmVehicle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;

            if (!IsPostBack)
            {
                MthdFillDrpAssign();
                MthdFillUserDrp();
            }
            mthdFillRepeater();

        }
        //DBInventoryEntities db = new DBInventoryEntities();

        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillDrpAssign()
        {
            DrpAssignTo.DataSource = (from a in db.tblRoles select new { a.RoleID, a.RoleDesc }).ToList();
            DrpAssignTo.DataValueField = "RoleID";
            DrpAssignTo.DataTextField = "RoleDesc";
            DrpAssignTo.DataBind();
        }
        public void MthdFillUserDrp()
        {
            int ID = int.Parse(DrpAssignTo.SelectedValue.ToString());

            DrpUser.DataSource = (from a in db.tblLogins
                                  let x = a.FirstName+" "+a.LastName
                                  select new { a.LoginID, x, a.RoleID }).Where(p => p.RoleID == ID).ToList();
            DrpUser.DataValueField = "LoginID";
            DrpUser.DataTextField = "x";
            DrpUser.DataBind();
        }

        public void mthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepVehicle().ToList().OrderByDescending(p => p.VehicleID);
            Repeater1.DataBind();
        }

        protected void DrpAssignTo_SelectedIndexChanged(object sender, EventArgs e)
        {

            MthdFillUserDrp();

        }
        public bool Empty()
        {
            if (txtdesc.Text.Trim() == string.Empty || txtVehicleNo.Text.Trim() == string.Empty
              || DrpUser.SelectedItem.Text == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtdesc.Text = "";
            txtVehicleNo.Text = "";
            DrpUser.SelectedIndex = 0;
            DrpAssignTo.SelectedIndex = 0;


        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                MthdAddVehicle();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdAddVehicle()
        {
            tblVehicle obj = new tblVehicle();

            obj.VehicleNo = txtVehicleNo.Text;
            obj.C_Description = txtdesc.Text;
            obj.LoginID = int.Parse(DrpUser.SelectedValue.ToString());

            db.tblVehicles.Add(obj);
            db.SaveChanges();

            lblmsg.Visible = true;
            lblmsg.Text = "Registered successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdClear();

        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblVehicle obj1 = db.tblVehicles.FirstOrDefault(r => r.VehicleID == id);

                    int UserID = int.Parse(obj1.LoginID.ToString());
                    tblLogin obj2 = db.tblLogins.FirstOrDefault(r => r.LoginID == UserID);

                    DrpAssignTo.SelectedValue = obj2.RoleID.ToString();

                    //  var rec = db.tblLogins.FirstOrDefault(p => p.RoleID == RoleID);

                    MthdFillUserDrp();
                    txtdesc.Text = obj1.C_Description;
                    txtVehicleNo.Text = obj1.VehicleNo;

                    DrpUser.SelectedValue = obj1.LoginID.ToString();

               



                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MthdUpdateVehicle();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdUpdateVehicle()
        {
            int id = int.Parse(HiddenField1.Value);
            var row = db.tblVehicles.Where(a => a.VehicleID == id).FirstOrDefault();
            if (row != null)
            {


                row.C_Description = txtdesc.Text;
                row.VehicleNo = txtVehicleNo.Text;

                row.LoginID = int.Parse(DrpUser.SelectedValue.ToString());

                db.SaveChanges();
                lblmsg.Visible = true;
                lblmsg.Text = "Record updated successfully!";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                btnUpdate.Visible = false;
                btnAdd.Visible = true;

                MthdClear();

            }
            else
            {
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
            }
        }
    }
}