﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class FrmProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            btnUpdate.Visible = false;
            mthdFillRepeater();
        }


        //DBInventoryEntities db = new DBInventoryEntities();


        DBInventoryEntities db = new DBInventoryEntities();
        public void mthdFillRepeater()
        {
            Repeater1.DataSource = db.tblVendors.ToList().OrderByDescending(p => p.VendorID);
            Repeater1.DataBind();
        }
        public bool Empty()
        {
            if (txtCity.Text.Trim() == string.Empty || txtCompanyName.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty
                || txtFName.Text.Trim() == string.Empty || txtLAstName.Text.Trim() == string.Empty || txtState.Text.Trim() == string.Empty
                || txtContactNo.Text.Trim() == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtState.Text = "";
            txtLAstName.Text = "";
            txtFName.Text = "";
            txtEmail.Text = "";
            txtContactNo.Text = "";
            txtCompanyName.Text = "";
            txtCity.Text = "";
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                MthdAddVendor();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdAddVendor()
        {
            tblVendor obj = new tblVendor();



            obj.FirstName = txtFName.Text;
            obj.LastName = txtLAstName.Text;
            obj.EmailID = txtEmail.Text;
            obj.AState = txtState.Text;
            obj.City = txtCity.Text;
            obj.CompanyName = txtCompanyName.Text;
            obj.ContactNo = txtContactNo.Text;


            db.tblVendors.Add(obj);
            db.SaveChanges();

            lblmsg.Visible = true;
            lblmsg.Text = "Registered successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdClear();




        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblVendor obj1 = db.tblVendors.FirstOrDefault(r => r.VendorID == id);


                    txtFName.Text = obj1.FirstName;
                    txtLAstName.Text = obj1.LastName;
                    txtState.Text = obj1.AState;
                    txtEmail.Text = obj1.EmailID;
                    txtContactNo.Text = obj1.ContactNo;
                    txtCompanyName.Text = obj1.CompanyName;
                    txtCity.Text = obj1.City;



                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                MthdUpdateVendor();
                mthdFillRepeater();
            }
            else
            {
                btnUpdate.Visible = true;
                btnAdd.Visible = false;
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdUpdateVendor()
        {
            int id = int.Parse(HiddenField1.Value);
            var row = db.tblVendors.Where(a => a.VendorID == id).FirstOrDefault();
            if (row != null)
            {


                row.FirstName = txtFName.Text;
                row.LastName = txtLAstName.Text;
                row.EmailID = txtEmail.Text;
                row.ContactNo = txtContactNo.Text;
                row.CompanyName = txtCompanyName.Text;
                row.City = txtCity.Text;
                row.AState = txtState.Text;



                db.SaveChanges();
                lblmsg.Visible = true;
                lblmsg.Text = "Record updated successfully!";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                btnUpdate.Visible = false;
                btnAdd.Visible = true;

                MthdClear();



            }
        }
    }
}