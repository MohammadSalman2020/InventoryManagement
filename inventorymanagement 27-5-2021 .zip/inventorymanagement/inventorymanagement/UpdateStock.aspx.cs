﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class UpdateStock : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                MthdFillDrpCustomer();
                MthdFillDrpProject();
                MthdFillDrpTruck2();
                MthdFillDrpPlace();
                MthdFillDrpPlace();
             //   MthdDrpTransferTo();
                mthdFillGrid();
                lblmsg.Visible = false;
            }

        }

        protected void DrpTransferFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpPlace();
            mthdFillGrid();
        }
        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillDrpCustomer()
        {
            DrpCustomer.DataSource = (from an in db.tblCustomers
                                      let x = an.FirstName + " " + an.LastName
                                      select new { an.CustomerID, x }).ToList();
            DrpCustomer.DataValueField = "CustomerID";
            DrpCustomer.DataTextField = "x";
            DrpCustomer.DataBind();
        }

        public void MthdFillDrpProject()
        {
            int id = int.Parse(DrpCustomer.SelectedValue.ToString());


            DrpProject.DataSource = (from an in db.tblProjects

                                     select new { an.ProjectID, an.Project, an.CustomerID }).Where(p => p.CustomerID == id).ToList();
            DrpProject.DataValueField = "ProjectID";
            DrpProject.DataTextField = "Project";
            DrpProject.DataBind();
        }



        //public void MthdDrpTransferTo()
        //{
        //    int x = DrpTransferto.SelectedIndex;

        //    if (x == 0)
        //    {
        //        Divtruck2.Visible = true;
        //        DivCus.Visible = false;
        //        txtCustomer.Text = "";
        //    }
        //    else if (x == 1)
        //    {
        //        Divtruck2.Visible = false;
        //        DivCus.Visible = true;
        //        txtCustomer.Text = DrpCustomer.SelectedItem.Text;
        //    }
        //}

        public void MthdFillDrpPlace()
        {
            int x = DrpTransferFrom.SelectedIndex;

            if (x == 0)
            {

                DrpWarehouse.DataSource = (from an in db.tblWarehouses

                                           select new { an.WarehouseID, an.WarehouseName }).ToList();
                DrpWarehouse.DataValueField = "WarehouseID";
                DrpWarehouse.DataTextField = "WarehouseName";
                DrpWarehouse.DataBind();
            }

            else if (x == 1)
            {
                int ID = int.Parse(DrpProject.SelectedValue.ToString());


                DrpWarehouse.DataSource = (from an in db.tblVehicleTrips
                                           join t2 in db.tblVehicles on an.VehicleID equals t2.VehicleID

                                           select new { an.VehicleID, t2.VehicleNo, an.ProjectID }).Where(p => p.ProjectID == ID).ToList();
                DrpWarehouse.DataValueField = "VehicleID";
                DrpWarehouse.DataTextField = "VehicleNo";
                DrpWarehouse.DataBind();
            }


        }


        public void MthdFillDrpTruck2()
        {

            int x = DrpTransferto.SelectedIndex;

            if(x==0)
            {
                int ID = int.Parse(DrpProject.SelectedValue.ToString());


                DrpTruck2.DataSource = (from an in db.tblVehicleTrips
                                        join t2 in db.tblVehicles on an.VehicleID equals t2.VehicleID

                                        select new { an.VehicleID, t2.VehicleNo, an.ProjectID }).Where(p => p.ProjectID == ID).ToList();
                DrpTruck2.DataValueField = "VehicleID";
                DrpTruck2.DataTextField = "VehicleNo";
                DrpTruck2.DataBind();
            }
            if(x==1)
            {
                int CustomerID = int.Parse(DrpCustomer.SelectedValue.ToString());
                DrpTruck2.DataSource = (from an in db.tblCustomers
                                          let y = an.FirstName + " " + an.LastName
                                        select new { an.CustomerID, y }).Where(p => p.CustomerID == CustomerID).ToList();
                DrpTruck2.DataValueField = "CustomerID";
                DrpTruck2.DataTextField = "y";
                DrpTruck2.DataBind();

                
            }
         
        }
        protected void DrpTransferto_SelectedIndexChanged(object sender, EventArgs e)
        {
          //  MthdDrpTransferTo();
            MthdFillDrpTruck2();
            MthdFillDrpPlace();
        }

        protected void DrpCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpProject();
            MthdFillDrpPlace();
            MthdFillDrpTruck2();
        }
        public void mthdFillGrid()
        {


            string PlaceType = DrpTransferFrom.SelectedItem.Text;
            int PlaceID = int.Parse(DrpWarehouse.SelectedValue.ToString());

            GridView1.DataSource = db.SpFillGridTransferUpdated(PlaceType, PlaceID).ToList();
            GridView1.DataBind();
        }
        protected void DrpProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpPlace();
            //txtCustomer.Text = DrpCustomer.SelectedItem.Text;
        }

        protected void DrpWarehouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            mthdFillGrid();
        }



        protected void btnTransaction_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                Label Quantity = GridView1.Rows[i].FindControl("lblQuantity") as Label;
                TextBox ReqQuantity = GridView1.Rows[i].FindControl("txtReqQty") as TextBox;


                if (ReqQuantity.Text.Trim() != "")
                {
                    tbltransaction obj = new tbltransaction();

                    obj.TransDate = Convert.ToDateTime(DateTime.Today);
                    obj.TransferFfrom = int.Parse(DrpWarehouse.SelectedValue.ToString());
                    obj.Sender = DrpTransferFrom.SelectedItem.Text;
                    if (DrpTransferto.SelectedItem.Text == "Truck")
                    {
                        obj.TransferTo = int.Parse(DrpTruck2.SelectedValue.ToString());
                        obj.Receiver = DrpTransferto.SelectedItem.Text;
                    }
                    else if (DrpTransferto.SelectedItem.Text == "Customer")
                    {
                        obj.TransferTo = int.Parse(DrpCustomer.SelectedValue.ToString());
                        obj.Receiver = DrpTransferto.SelectedItem.Text;
                    }

                    obj.ProductID = int.Parse(prodID.Text);
                    obj.Before = int.Parse(Quantity.Text);
                    obj.Plus = 0;
                    obj.Minus = double.Parse(ReqQuantity.Text);

                    float ProductQuantity = float.Parse(Quantity.Text);
                    float RequiredQty = float.Parse(ReqQuantity.Text);

                    float Total = ProductQuantity - RequiredQty;

                    obj.After_ = Total;
                    obj.Remarks = "Warehouse to Truck";





                    
                    string PlaceType = DrpTransferFrom.SelectedItem.Text;
                    int ProductID = int.Parse(prodID.Text);


                    var row = db.tblCurrentStocks.Where(a => a.PlaceType == PlaceType && a.ProductID == ProductID).FirstOrDefault();
                    if (row != null)
                    {
                        row.Qty = obj.After_;
                    }







                    db.tbltransactions.Add(obj);
                    db.SaveChanges();



                    tbltransaction obj2 = new tbltransaction();

                    obj2.TransDate = Convert.ToDateTime(DateTime.Today);
                    obj2.TransferFfrom = int.Parse(DrpWarehouse.SelectedValue.ToString());
                    obj2.Sender = DrpTransferFrom.SelectedItem.Text;
                    if (DrpTransferto.SelectedItem.Text == "Truck")
                    {
                        obj2.TransferTo = int.Parse(DrpTruck2.SelectedValue.ToString());
                        obj2.Receiver = DrpTransferto.SelectedItem.Text;
                    }
                    else if (DrpTransferto.SelectedItem.Text == "Customer")
                    {
                        obj2.TransferTo = int.Parse(DrpCustomer.SelectedValue.ToString());
                        obj2.Receiver = DrpTransferto.SelectedItem.Text;
                    }

                       string PlaceType1 = DrpTransferto.SelectedItem.Text;
                    int ProductID1 = int.Parse(prodID.Text);
                    int PlaceID = int.Parse(DrpTruck2.SelectedValue.ToString());

                    obj2.ProductID = int.Parse(prodID.Text);

                    var rec3 = db.tblCurrentStocks.Where(a => a.PlaceType == PlaceType1 && a.ProductID == ProductID1 && a.PlaceID == PlaceID).FirstOrDefault();

                    if(rec3!=null)
                    {
                        obj2.Before = rec3.Qty;
                    }
                    else
                    {
                        obj2.Before = 0;


                        tblCurrentStock obj3 = new tblCurrentStock();
                        obj3.PlaceType = DrpTransferto.SelectedItem.Text;

                        if (DrpTransferto.SelectedItem.Text == "Truck")
                        {
                            obj3.PlaceID = int.Parse(DrpTruck2.SelectedValue.ToString());
                        }
                        else if (DrpTransferto.SelectedItem.Text == "Customer")
                        {
                            obj3.PlaceID = int.Parse(DrpCustomer.SelectedValue.ToString());
                        }

                        obj3.ProductID = int.Parse(prodID.Text);
                        obj3.Qty = float.Parse(ReqQuantity.Text);

                        db.tblCurrentStocks.Add(obj3);
                        db.SaveChanges();

                    }



                   
                    obj2.Plus = double.Parse(ReqQuantity.Text);
                    obj2.Minus = 0;

                    obj2.Remarks = "Warehouse to Truck";

                    float ProductQuantity1 = float.Parse(obj2.Before.ToString());
                    float RequiredQty1 = float.Parse(ReqQuantity.Text);

                    float Total1 = ProductQuantity1 + RequiredQty1;

                    obj2.After_ = Total1;


                 


                    var row1 = db.tblCurrentStocks.Where(a => a.PlaceType == PlaceType1 && a.ProductID == ProductID1&&a.PlaceID==PlaceID).FirstOrDefault();
                    if (row1 != null)
                    {
                        row1.Qty = obj2.After_;
                    }





                    db.tbltransactions.Add(obj2);
                    db.SaveChanges();



                }







                else
                {
                    continue;
                }

            }
            Response.Redirect("UpdateStock.aspx");
            lblmsg.Visible = true;
            lblmsg.Text = "Added successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
        }
    }

}
