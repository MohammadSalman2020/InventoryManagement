﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class UpdateDamage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                MthdFillDrpCustomer();
                MthdFillDrpProject();
                MthdFillDrpVehicle();
               
                mthdFillGrid();

                if (DrpVehicle.SelectedValue.ToString() == "")
                {
                    GridView1.Visible = false;
                }
                else
                {
                    GridView1.Visible = true;
                }
            }
            btnUpdate.Visible = false;
            lblmsg.Visible = false;
          
        }
        DBInventoryEntities db = new DBInventoryEntities();
        public void MthdFillDrpCustomer()
        {
            DrpCustomer.DataSource = (from a in db.tblCustomers 
                                      let x = a.FirstName+" "+a.LastName
                                      select new { a.CustomerID, x }).ToList();
            DrpCustomer.DataValueField = "CustomerID";
            DrpCustomer.DataTextField = "x";
            DrpCustomer.DataBind();

        }
        public void MthdFillDrpProject()
        {
            int CustomerID = int.Parse(DrpCustomer.SelectedValue.ToString());
            DrpProject.DataSource = (from a in db.tblProjects
                                      select new { a.CustomerID, a.ProjectID, a.Project }).ToList().Where(p => p.CustomerID == CustomerID);
            DrpProject.DataValueField = "ProjectID";
            DrpProject.DataTextField = "Project";
            DrpProject.DataBind();
        

        }
        public void mthdFillGrid()
        {


            string PlaceType = "Truck";
            int PlaceID = int.Parse(DrpVehicle.SelectedValue.ToString());

            GridView1.DataSource = db.SpFillGridTransferUpdated(PlaceType, PlaceID).ToList();
            GridView1.DataBind();
        }
        public void MthdFillDrpVehicle()
        {

        

          
                int ID = int.Parse(DrpProject.SelectedValue.ToString());


                DrpVehicle.DataSource = (from an in db.tblVehicleTrips
                                        join t2 in db.tblVehicles on an.VehicleID equals t2.VehicleID

                                        select new { an.VehicleID, t2.VehicleNo, an.ProjectID }).Where(p => p.ProjectID == ID).ToList();
                DrpVehicle.DataValueField = "VehicleID";
                DrpVehicle.DataTextField = "VehicleNo";
                DrpVehicle.DataBind();
          

        }
 

        protected void DrpCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpProject();
            MthdFillDrpVehicle();
            if (DrpVehicle.SelectedValue.ToString() == "")
            {
                GridView1.Visible = false;
            }
            else
            {
                GridView1.Visible = true;
            }
           
        }

        protected void DrpProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdFillDrpVehicle();
            if (DrpVehicle.SelectedValue.ToString() == "")
            {
                GridView1.Visible = false;
            }
            else
            {
                GridView1.Visible = true;
            }
          
        }

        protected void DrpVehicle_SelectedIndexChanged(object sender, EventArgs e)
        {
            mthdFillGrid();
        }
        
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if(txtDamage.Text.Trim()!="")
            {

          
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                Label Quantity = GridView1.Rows[i].FindControl("lblQuantity") as Label;
                TextBox ReqQuantity = GridView1.Rows[i].FindControl("txtReqQty") as TextBox;


                if (ReqQuantity.Text.Trim() != "")
                {

                    tbltransaction obj = new tbltransaction();


                    obj.TransDate = Convert.ToDateTime(DateTime.Today);
                    obj.TransferFfrom = int.Parse(DrpVehicle.SelectedValue.ToString());
                    obj.Sender = "Truck";
                    obj.TransferTo = int.Parse(DrpCustomer.SelectedValue.ToString());
                    obj.Receiver = "Customer";

                    obj.ProductID = int.Parse(prodID.Text);
                    obj.Before = float.Parse(Quantity.Text);
                    obj.Plus = 0;
                    obj.Minus = float.Parse(ReqQuantity.Text);

                    float QuantityBefore = float.Parse(Quantity.Text);
                    float Demaged = float.Parse(ReqQuantity.Text);

                    float Total = QuantityBefore - Demaged;

                    obj.After_ = Total;

                    obj.Remarks = "Demaged" + "- " + txtDamage.Text;

                    db.tbltransactions.Add(obj);
                    db.SaveChanges();

                  

                    string PlaceType1 = "Truck";
                    int ProductID1 = int.Parse(prodID.Text);
                    int PlaceID = int.Parse(DrpVehicle.SelectedValue.ToString());

                    var row1 = db.tblCurrentStocks.Where(a => a.PlaceType == PlaceType1 && a.ProductID == ProductID1 && a.PlaceID == PlaceID).FirstOrDefault();
                    if (row1 != null)
                    {
                        row1.Qty = obj.After_;
                        db.SaveChanges();
                    }

                }
            }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }

            Response.Redirect("UpdateDamage.aspx");

        }
    }
}