﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class VehicleTrip : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                MthdFillDrpVehicle();
                MthdFillDrpProject();
                MthdFillDrpSupportVehicle();
            }


            mthdFillRepeater();
            DivRemarks.Visible = false;
            DivSupportVehicle.Visible = false;
            mthdHideSupportVehicle();
            btnUpdate.Visible = false;
            lblmsg.Visible = false;
        }

        public void mthdHideSupportVehicle()
        {
            if (CheckBox1.Checked == true)
            {

                DivRemarks.Visible = true;
                DivSupportVehicle.Visible = true;
            }
            else
            {

                DivRemarks.Visible = false;
                DivSupportVehicle.Visible = false;
            }
        }
        //DBInventoryEntities db = new DBInventoryEntities();

        DBInventoryEntities db = new DBInventoryEntities();
       

        public void MthdFillDrpVehicle()
        {
            DrpVehicle.DataSource = (from a in db.tblVehicles select new { a.VehicleID, a.VehicleNo }).ToList();
            DrpVehicle.DataValueField = "VehicleID";
            DrpVehicle.DataTextField = "VehicleNo";
            DrpVehicle.DataBind();
        }
        public void MthdFillDrpSupportVehicle()
        {
            DrpSupportingVehicle.DataSource = (from a in db.tblVehicles select new { a.VehicleID, a.VehicleNo }).ToList();
            DrpSupportingVehicle.DataValueField = "VehicleID";
            DrpSupportingVehicle.DataTextField = "VehicleNo";
            DrpSupportingVehicle.DataBind();
        }
        public void MthdFillDrpProject()
        {
            DrpProject.DataSource = (from a in db.tblProjects select new { a.ProjectID, a.Project }).ToList();
            DrpProject.DataValueField = "ProjectID";
            DrpProject.DataTextField = "Project";
            DrpProject.DataBind();
        }
        public bool Empty()
        {
            if (txtCurrentMilage.Text.Trim() == string.Empty || txtDate.Text.Trim() == string.Empty
              || txtMilesDriven.Text == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }
        public void MthdClear()
        {
            txtRemarks.Text = "";
            txtMilesDriven.Text = "";
            txtDate.Text = "";
            txtCurrentMilage.Text = "";


        }
        public void mthdFillRepeater()
        {
            Repeater1.Visible = false;
            Repeater2.Visible = false;
            if (CheckBox1.Checked == true)
            {
                Repeater1.Visible = true;
                Repeater1.DataSource = db.SpFillRepVehivleTrip2().ToList().OrderByDescending(p => p.TripID);
                Repeater1.DataBind();
            }
            else
            {
                Repeater2.Visible = true;
                Repeater2.DataSource = db.SpFillRepVehivleTripNotNull().ToList().OrderByDescending(p => p.TripID);
                Repeater2.DataBind();
            }

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                MthdAddVehicleTrip();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void MthdAddVehicleTrip()
        {
            tblVehicleTrip obj = new tblVehicleTrip();

            if (CheckBox1.Checked == true)
            {
                obj.CurrentMilege = int.Parse(txtCurrentMilage.Text);
                obj.MilesDriven = int.Parse(txtMilesDriven.Text);
                obj.ProjectID = int.Parse(DrpProject.SelectedValue.ToString());
                obj.Remarks = txtRemarks.Text;

                string test11 = obj.TripDate.ToString();
                txtDate.Text = DateTime.Parse(test11).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                //obj.TripDate = Convert.ToDateTime(txtDate.Text);




                obj.VehicleID = int.Parse(DrpVehicle.SelectedValue.ToString());
                obj.VehicleIDD = int.Parse(DrpSupportingVehicle.SelectedValue.ToString());

                db.tblVehicleTrips.Add(obj);
                db.SaveChanges();
            }
            else
            {
                obj.CurrentMilege = int.Parse(txtCurrentMilage.Text);
                obj.MilesDriven = int.Parse(txtMilesDriven.Text);
                obj.ProjectID = int.Parse(DrpProject.SelectedValue.ToString());

                obj.TripDate = Convert.ToDateTime(txtDate.Text);
                obj.VehicleID = int.Parse(DrpVehicle.SelectedValue.ToString());


                db.tblVehicleTrips.Add(obj);
                db.SaveChanges();
            }



            lblmsg.Visible = true;
            lblmsg.Text = "Registered successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            MthdClear();

        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblVehicleTrip obj1 = db.tblVehicleTrips.FirstOrDefault(r => r.TripID == id);


                    txtCurrentMilage.Text = obj1.CurrentMilege.ToString();
                    txtMilesDriven.Text = obj1.MilesDriven.ToString();
                    txtRemarks.Text = obj1.Remarks;

                    string test11 = obj1.TripDate.ToString();
                    txtDate.Text = DateTime.Parse(test11).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    DrpProject.SelectedValue = obj1.ProjectID.ToString();
                    DrpSupportingVehicle.SelectedValue = obj1.VehicleIDD.ToString();
                    DrpVehicle.SelectedValue = obj1.VehicleID.ToString();

                        btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void Repeater2_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblVehicleTrip obj1 = db.tblVehicleTrips.FirstOrDefault(r => r.TripID == id);


                    txtCurrentMilage.Text = obj1.CurrentMilege.ToString();
                    txtMilesDriven.Text = obj1.MilesDriven.ToString();


                    string test11 = obj1.TripDate.ToString();
                    txtDate.Text = DateTime.Parse(test11).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

                    DrpProject.SelectedValue = obj1.ProjectID.ToString();

                    DrpVehicle.SelectedValue = obj1.VehicleID.ToString();

                    btnAdd.Visible = false;
                    btnUpdate.Visible = true;





                    break;
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                UpdateVehicleTrip();
                mthdFillRepeater();
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }

        public void UpdateVehicleTrip()
        {

            int id = int.Parse(HiddenField1.Value);
            var row = db.tblVehicleTrips.Where(a => a.TripID == id).FirstOrDefault();
            if (row != null)
            {

                if (CheckBox1.Checked == true)
                {
                    row.CurrentMilege = int.Parse(txtCurrentMilage.Text);
                    row.MilesDriven = int.Parse(txtMilesDriven.Text);
                    row.Remarks = txtRemarks.Text;
                    row.TripDate = Convert.ToDateTime(txtDate.Text);


                    row.VehicleID = int.Parse(DrpVehicle.SelectedValue.ToString());
                    row.VehicleIDD = int.Parse(DrpSupportingVehicle.SelectedValue.ToString());
                    row.ProjectID = int.Parse(DrpProject.SelectedValue.ToString());



                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record updated successfully!";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                    btnUpdate.Visible = false;
                    btnAdd.Visible = true;

                    MthdClear();

                }
                else
                {
                    row.CurrentMilege = int.Parse(txtCurrentMilage.Text);
                    row.MilesDriven = int.Parse(txtMilesDriven.Text);
                    row.TripDate = Convert.ToDateTime(txtDate.Text);
                    row.VehicleID = int.Parse(DrpVehicle.SelectedValue.ToString());
                    row.ProjectID = int.Parse(DrpProject.SelectedValue.ToString());



                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record updated successfully!";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                    btnUpdate.Visible = false;
                    btnAdd.Visible = true;

                    MthdClear();
                }
            }

        }
    }
}
