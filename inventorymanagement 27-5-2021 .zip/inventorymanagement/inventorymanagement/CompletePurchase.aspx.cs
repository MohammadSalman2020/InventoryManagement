﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace inventorymanagement
{
    public partial class CompletePurchase : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               
                mthdFillGrid();
                MthdFillDrpVendor();
                MthdFillDrpWarehouse();
              
                DivFile.Visible = false;
                MthdFillForm();
                lblmsg.Visible = false;
            }
        }

        DBInventoryEntities db = new DBInventoryEntities();
        public void mthdFillGrid()
        {
            GridView1.DataSource = (from a in db.tblProducts
                                    select new { a.ProductID, a.ProductName }).ToList();
            GridView1.DataBind();
        }


        public void MthdFillDrpVendor()
        {

            DrpVendor.DataSource = (from a in db.tblVendors 
                                    let x = a.FirstName+" "+a.LastName

                                    select new { a.VendorID, x }).ToList();
            DrpVendor.DataValueField = "VendorID";
            DrpVendor.DataTextField = "x";
            DrpVendor.DataBind();



        }
        public void MthdFillDrpWarehouse()
        {

            DrpWarehouse.DataSource = (from a in db.tblWarehouses select new { a.WarehouseID, a.WarehouseName }).ToList();
            DrpWarehouse.DataValueField = "WarehouseID";
            DrpWarehouse.DataTextField = "WarehouseName";
            DrpWarehouse.DataBind();



        }
        public bool Empty()
        {
            if (txtPurchaseDate.Text.Trim() == string.Empty || txtRemarks.Text.Trim() == string.Empty
                || txtShipingCost.Text.Trim() == string.Empty || txtShipment.Text.Trim() == string.Empty)
            {

                return true;

            }
            else
            {
                return false;
            }
        }

        public void MthdFillForm()
        {
            int id = int.Parse(Session["PurchaseID"].ToString());
           
            tblPurchase obj1 = db.tblPurchases.FirstOrDefault(r => r.PurchaseID == id);







            txtShipment.Text = obj1.ShipmentID;
            txtShipingCost.Text = obj1.ShippingCost.ToString();
            txtRemarks.Text = obj1.Remarks;
            DrpVendor.SelectedValue = obj1.VendorID.ToString();
            DrpWarehouse.SelectedValue = obj1.WarehouseID.ToString();


            string test11 = obj1.PurchaseDate.ToString();
            txtPurchaseDate.Text = DateTime.Parse(test11).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

         

            var obj2 = db.tblPurchaseDetails.Where(r => r.PurchaseID == id).ToList();





            var x = db.spFillGrtidOnEditPurchaseCratedBySiddiqueMaster(id).FirstOrDefault();

            GridView1.DataSource = db.spFillGrtidOnEditPurchaseCratedBySiddiqueMaster(id).ToList();
            GridView1.DataBind();

         

            for (int i = 0; i < obj2.Count; i++)
            {
                Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                Label ProductName = GridView1.Rows[i].FindControl("lblproductname") as Label;
                TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;

                int y = int.Parse(obj2[i].ProductID.ToString());
                var rec = db.tblProducts.Where(a => a.ProductID == y).FirstOrDefault();

                prodID.Text = obj2[i].ProductID.ToString();
                unit.Text = obj2[i].PricePerUnit.ToString();
                measurement.Text = obj2[i].Measurement.ToString();
                quantity.Text = obj2[i].Quantity.ToString();
                ProductName.Text = rec.ProductName.ToString();

            }

          
          


            DivFile.Visible = false;
            file_Decision.Visible = true;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                int PurchaseID = int.Parse(Session["PurchaseID"].ToString());
                db.SpInsertCompletePurchaseUpdate(PurchaseID);
                db.SaveChanges();
                MthdUpdatePurchase();
                Response.Redirect("OrderTrack.aspx");

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all feilds";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public void MthdUpdatePurchase()
        {
            try
            {

                int id = int.Parse(Session["PurchaseID"].ToString());
                var row = db.tblPurchases.Where(a => a.PurchaseID == id).FirstOrDefault();
                if (row != null)
                {



                    if (FileUpload1.HasFile)
                    {
                        string FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                        string Picturepath = "/PuchaseOrderPicture/" + FileName;

                        FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);

                        // fileimagesave.SaveAs("images/"+ imgfile);
                        FileUpload1.SaveAs(Server.MapPath("~/PuchaseOrderPicture/") + FileName);


                        row.PoImage = Picturepath;
                        row.PurchaseDate = Convert.ToDateTime(txtPurchaseDate);
                        row.Remarks = txtRemarks.Text;
                        row.ShipmentID = txtShipment.Text;
                        row.ShippingCost = double.Parse(txtShipingCost.Text);
                        row.VendorID = int.Parse(DrpVendor.SelectedValue.ToString());
                        row.WarehouseID = int.Parse(DrpWarehouse.SelectedValue.ToString());
                        row.PurchaseStatus = "Completed";

                        db.SpDeletePurchaseDetail(id);
                        db.SaveChanges();

                     //   var obj2 = db.tblPurchaseDetails.Where(r => r.PurchaseID == id).ToList();
                        for (int i = 0; i < GridView1.Rows.Count; i++)
                        {
                            Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                            TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                            TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                            TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;

                            if (unit.Text.Trim() != "" || measurement.Text.Trim() != "" || quantity.Text.Trim() != "")
                            {
                                //obj2[i].PricePerUnit = double.Parse(unit.Text);
                                //obj2[i].Measurement = measurement.Text;
                                //obj2[i].Quantity = double.Parse(quantity.Text);

                                db.SpUpdateCompletePurchase(id, int.Parse(prodID.Text), measurement.Text, double.Parse(quantity.Text.ToString()), double.Parse(unit.Text.ToString()));
                                db.SaveChanges();

                                db.spAddPurcahseTrans("Warehouse", int.Parse(DrpWarehouse.SelectedValue.ToString()), int.Parse(prodID.Text), Convert.ToDateTime(""), id, int.Parse(DrpVendor.SelectedValue.ToString()),
                                    DrpVendor.SelectedItem.Text, int.Parse(DrpWarehouse.SelectedValue.ToString()), DrpWarehouse.SelectedItem.Text, double.Parse(quantity.Text), "");

                                db.SaveChanges();



                            }
                            else
                            {
                                lblmsg.Visible = true;
                                lblmsg.Text = "Please Enter Details of Products";
                                lblmsg.ForeColor = System.Drawing.Color.Red;
                            }
                        }

                    }
                    else
                    {
                        row.PurchaseDate = Convert.ToDateTime(txtPurchaseDate.Text);
                        row.Remarks = txtRemarks.Text;
                        row.ShipmentID = txtShipment.Text;
                        row.ShippingCost = double.Parse(txtShipingCost.Text);
                        row.VendorID = int.Parse(DrpVendor.SelectedValue.ToString());
                        row.WarehouseID = int.Parse(DrpWarehouse.SelectedValue.ToString());
                        row.PurchaseStatus = "Completed";

                 //       var obj2 = db.tblPurchaseDetails.Where(r => r.PurchaseID == id).ToList();


                        db.SpDeletePurchaseDetail(id);
                        db.SaveChanges();


                        for (int i = 0; i < GridView1.Rows.Count; i++)
                        {
                            Label prodID = GridView1.Rows[i].FindControl("lblID") as Label;
                            TextBox unit = GridView1.Rows[i].FindControl("txtUnit") as TextBox;
                            TextBox measurement = GridView1.Rows[i].FindControl("txtMeasurement") as TextBox;
                            TextBox quantity = GridView1.Rows[i].FindControl("txtQuantity") as TextBox;

                            if (unit.Text.Trim() != "" || measurement.Text.Trim() != "" || quantity.Text.Trim() != "")
                            {
                                //obj2[i].PricePerUnit = double.Parse(unit.Text);
                                //obj2[i].Measurement = measurement.Text;
                                //obj2[i].Quantity = double.Parse(quantity.Text);


                                db.SpUpdateCompletePurchase(id, int.Parse(prodID.Text), measurement.Text, double.Parse(quantity.Text.ToString()), double.Parse(unit.Text.ToString()));
                                db.SaveChanges();

                                db.spAddPurcahseTrans("Warehouse", int.Parse(DrpWarehouse.SelectedValue.ToString()), int.Parse(prodID.Text),Convert.ToDateTime(txtPurchaseDate.Text), id, int.Parse(DrpVendor.SelectedValue.ToString()),
                                 DrpVendor.SelectedItem.Text, int.Parse(DrpWarehouse.SelectedValue.ToString()), DrpWarehouse.SelectedItem.Text, double.Parse(quantity.Text), "");

                                db.SaveChanges();

                            }
                            else
                            {
                                continue;
                            }
                        }


                    }





                    db.SaveChanges();



                    btnAdd.Visible = true;

                    
                 

                   lblmsg.Visible = true;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }

            }
            catch (Exception ex)
            {

            }
        }
    }
}